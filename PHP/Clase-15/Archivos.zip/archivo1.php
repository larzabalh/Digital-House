<?php
namespace prueba\ejemplo\subnamespace;

const PRUEBA = 1;
function prueba() {}
class prueba
{
    static function staticmethod() {}
}
?>
